Sources: https://github.com/tecnickcom/

Versions:
tc-lib-color   1.5.1
tc-lib-barcode 1.4.2
