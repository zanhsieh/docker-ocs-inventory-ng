<h3><?php echo  $l->g(1123);?></h3>
<?php
	iframe("//webchat.freenode.net/?channels=ocsinventory-ng&uio=d4");