<h3><?php echo  $l->g(1377);?></h3>
<?php
	iframe("//ask.ocsinventory-ng.org/questions");