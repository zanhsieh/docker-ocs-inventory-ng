<h3><?php echo  $l->g(1122);?></h3>
<?php
	iframe("//wiki.ocsinventory-ng.org");